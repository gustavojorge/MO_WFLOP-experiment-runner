#ifndef ISEQUAL_H
#define ISEQUAL_H

#include "../../modules/headers/generate_rSolution.h"
using namespace std;

bool isEqual(Solution solutionA, Solution solutionB);

#endif 