#ifndef MUTATION_FEATURE_H
#define MUTATION_FEATURE_H

#include "../../../../modules/headers/population.h"

void mutationFeature(Solution &solution);

#endif 
