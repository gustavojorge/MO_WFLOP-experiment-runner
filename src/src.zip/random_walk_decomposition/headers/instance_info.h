#ifndef INSTANCE_H
#define INSTANCE_H

void get_instance_info(int argc, char* argv[]);

#endif
