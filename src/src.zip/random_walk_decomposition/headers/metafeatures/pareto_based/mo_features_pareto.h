#ifndef MO_METAFEATURES_PARETO_H
#define MO_METAFEATURES_PARETO_H

#include "../landscapeMetrics.h"

std::vector<double> mo_features_extraction_pareto(LandscapeMetrics landscapesMetrics);

#endif 
