#ifndef UPDATEEP_H
#define UPDATEEP_H

#include <vector>
#include "generate_rSolution.h"
using namespace std;

void updateEP(vector<Solution> &EP, Solution &child);

#endif 
