#ifndef MUTATION2_H
#define MUTATION2_H

#include <vector>
#include "population.h"
using namespace std;

void mutation2(Solution &solution, double input_mutation_prob, vector<Solution> &EP);

#endif 
