#ifndef DOMINATES_H
#define DOMINATES_H

#include "generate_rSolution.h"
using namespace std;

bool dominates(Solution solutionA, Solution solutionB);

#endif 