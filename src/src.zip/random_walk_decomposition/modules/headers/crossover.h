#ifndef CROSSOVER_H
#define CROSSOVER_H

#include "population.h"
using namespace std;

Solution crossover(Solution &parent_solutionA, Solution &parent_solutionB);

#endif 
