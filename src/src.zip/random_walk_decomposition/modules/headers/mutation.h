#ifndef MUTATION_H
#define MUTATION_H

#include <vector>
#include "population.h"
using namespace std;

void mutation(Solution &solution);

#endif 
