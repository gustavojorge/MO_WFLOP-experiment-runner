#ifndef NSGA2_H
#define NSGA2_H

#include "generate_rSolution.h"
#include <vector>
using namespace std;

vector<Solution> nsga2(vector<Solution>& population);

#endif 