#ifndef CROWDING_DISTANCE_H
#define CROWDING_DISTANCE_H

#include "generate_rSolution.h"
#include <vector>
using namespace std;

vector<Solution> crowding_distance(vector<Solution> &population);

#endif 