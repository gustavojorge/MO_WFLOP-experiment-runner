#ifndef MAIN_H
#define MAIN_H

#include "population.h"
#include "generate_rSolution.h"
#include "mutation.h"
#include "crossover.h"
#include "turbine.h"

#endif 